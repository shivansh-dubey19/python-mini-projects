# CSV Data Cleaning Script
import pandas as pd

# Load CSV file
df = pd.read_csv('data.csv')

# Drop rows with null values
df_cleaned = df.dropna()

# Rename columns for clarity
df_cleaned = df_cleaned.rename(columns=lambda x: x.strip().replace(' ', '_').lower())

# Save cleaned data
df_cleaned.to_csv('cleaned_data.csv', index=False)
print("Data cleaned and saved as 'cleaned_data.csv'")