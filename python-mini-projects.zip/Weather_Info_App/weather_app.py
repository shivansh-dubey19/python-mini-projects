# Weather Info App using OpenWeatherMap API
import requests

API_KEY = 'YOUR_API_KEY_HERE'  # Replace with your API key
BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"

city = input("Enter city name: ")
complete_url = BASE_URL + "appid=" + API_KEY + "&q=" + city + "&units=metric"

response = requests.get(complete_url)
data = response.json()

if data["cod"] != "404":
    main = data["main"]
    weather = data["weather"][0]
    print(f"Temperature: {main['temp']}°C")
    print(f"Humidity: {main['humidity']}%")
    print(f"Weather: {weather['description']}")
else:
    print("City Not Found!")