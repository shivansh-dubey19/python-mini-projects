# Student Marks Dashboard (CLI Project)
students = {}

def add_student(name, marks):
    students[name] = marks

def view_students():
    for name, marks in students.items():
        print(f"Name: {name}, Marks: {marks}")

def average_marks():
    if students:
        avg = sum(students.values()) / len(students)
        print(f"Average Marks: {avg}")
    else:
        print("No student records.")

while True:
    print("\n1. Add Student\n2. View Students\n3. Average Marks\n4. Exit")
    choice = input("Enter choice: ")
    if choice == '1':
        name = input("Enter name: ")
        marks = int(input("Enter marks: "))
        add_student(name, marks)
    elif choice == '2':
        view_students()
    elif choice == '3':
        average_marks()
    elif choice == '4':
        break
    else:
        print("Invalid choice.")