# Python Mini Projects

## 1. Student Marks Dashboard
A command-line tool to manage student records, view marks, and calculate averages.

## 2. Weather Info App
Fetch live weather details by city name using OpenWeatherMap API.

## 3. CSV Data Cleaning Script
Clean messy CSV data by removing nulls and renaming columns using Pandas.